# Команды и права доступа

Основная команда плагина: **`/wardrobe`**  
Алиасы: **`/wd`**, **`/clothes`**, **`/одеть`**

Все подкоманды поддерживают динамическое **Tab-автодополнение** (включая новые слои из `layers.yml`, текстуры из `overlays/`, `.bbmodel` из MythicArmors и шорткаты блокировки).

---

## Таблица прав доступа (Permissions)

| Право | По умолчанию | Описание |
| :--- | :--- | :--- |
| `mythicwardrobe.use` | `true` | Открытие гардероба (`/wardrobe`, `/wardrobe open`), переключение режима меню (`/wardrobe mode`), смена типа рук (`/wardrobe bodytype`) и клики по слотам брони в инвентаре. |
| `mythicwardrobe.quickequip` | `true` | Быстрое надевание 2D-одежды ПКМ в воздухе из хотбара (`inventory-trigger.right-click-quick-equip: true`). |
| `mythicwardrobe.bypass.handequip` | `false` | Обход запрета на надевание брони через ПКМ в руке (`inventory-trigger.disable-hand-right-click-armor-equip: true`). |
| `mythicwardrobe.web` | `true` | Получение одноразовой ссылки на встроенный тестовый веб-редактор (`/wardrobe web`). |
| `mythicwardrobe.admin` | `op` | Все административные команды (`set`, `clear`, `reset`, `layers`, `tag`, `block`, `merge`, `buildheadpack`, `list`, `prewarm`, `reload`, `debug`, управление другими игроками). |

---

## Команды для игроков

| Команда | Алиасы подкоманды | Право | Описание |
| :--- | :--- | :--- | :--- |
| `/wardrobe` | — | `mythicwardrobe.use` | Открывает гардероб в текущем выбранном режиме игрока (`COMPACT` / `TABBED` / `UNIFIED`). |
| `/wardrobe open [раздел]` | — | `mythicwardrobe.use` | Открывает конкретный экран: `head`, `chest`, `legs`, `feet`, `hub`, `unified` (или `all`). |
| `/wardrobe mode <режим>` | `menu`, `style`, `gui` | `mythicwardrobe.use` | Переключает личный вид меню: `compact`, `tabbed`, `unified` или `default` (работает при `allow-player-switch: true` в `menus.yml`). |
| `/wardrobe bodytype <тип>` | `body_type`, `arms` | `mythicwardrobe.use` | Переключает толщину рук скина: `slim` (Alex 3px), `wide` (Steve 4px) или `auto`. |
| `/wardrobe web` | `editor` | `mythicwardrobe.web` | Выдаёт личную одноразовую ссылку на встроенный тестовый 3D-редактор скина (если включён в `config.yml`). |

---

## Административные команды (`mythicwardrobe.admin`)

### Управление меню, слоями и типом тела игроков

| Команда | Описание | Пример |
| :--- | :--- | :--- |
| `/wardrobe open <раздел> <игрок>` | Принудительно открыть нужный раздел гардероба указанному игроку. | `/wardrobe open chest Steve` |
| `/wardrobe mode <игрок> <compact\|tabbed\|unified\|default>` | Установить режим меню другому игроку. | `/wardrobe mode Steve unified` |
| `/wardrobe bodytype <игрок> <slim\|wide\|auto>` | Установить тип рук другому игроку. | `/wardrobe bodytype Steve slim` |
| `/wardrobe web <игрок>` | Отправить ссылку встроенного веб-редактора конкретному игроку. | `/wardrobe web Steve` |
| `/wardrobe set <игрок> <тип_слоя> <файл.png> [blocks_csv]` | Наложить 2D-слой скина (поддерживает ID и алиасы из `layers.yml`; опционально с блокировкой других слоёв). | `/wardrobe set Steve jacket leather_brown.png` |
| `/wardrobe clear <игрок> <тип_слоя\|all>` | Снять конкретный 2D-слой (подкоманда также имеет алиасы `unwear`, `remove`) или все слои (`all`). | `/wardrobe clear Steve jacket` |
| `/wardrobe reset [игрок]` | Полностью сбросить все 2D-слои, наложенные командами/скиллами, и пересобрать скин. | `/wardrobe reset Steve` |

> **Примечание:** у `set` есть алиас `wear`, у `clear` — `unwear` и `remove`.

### Тегирование предметов и блокировки (в руке)

| Команда | Алиасы | Описание | Пример |
| :--- | :--- | :--- | :--- |
| `/wardrobe tag <slotId> [файл.png] [blocks_csv] [UNEQUIP\|PREVENT\|HIDE]` | — | Записывает PDC-тег прямо в предмет в основной руке: привязывает его к слоту гардероба, задаёт 2D-текстуру и (опционально) список блокируемых слоёв + режим блокировки. | `/wardrobe tag jacket hazmat_suit.png suit,mask_skin,hat UNEQUIP` |
| `/wardrobe block <цели\|clear> [UNEQUIP\|PREVENT\|HIDE]` | `blocks`, `lock` | Добавляет, меняет или снимает (`clear`/`none`/`reset`) блокировку слоёв/слотов у предмета в основной руке. Поддерживает групповые шорткаты `all_clothing`, `all_body`, `suit`, `all_skin`, `all_3d`, `all_cosmetic`, `all`. | `/wardrobe block pants,undershirt,belt_skin,gloves,socks,boots_skin,mask_skin,hat UNEQUIP` |

### 3D-инструменты MythicArmors

| Команда | Алиасы | Описание | Пример |
| :--- | :--- | :--- | :--- |
| `/wardrobe merge <modelA> <modelB> <outputName>` | `combine` | Склеивает два `.bbmodel` файла из `plugins/MythicArmors/models/` в один комбо-файл с общим текстурным атласом и объединёнными костями (для 0-lag комбо без ArmorStand). | `/wardrobe merge tactical_warden tactical_backpack tactical_warden_backpack` |
| `/wardrobe buildheadpack [слоёв]` | `headpack` | Читает `plugins/MythicArmors/pack.zip` и собирает `plugins/MythicWardrobe/merged_pack.zip` + `head_composite_manifest.json` для безлимитных 3D-слоёв головы (`minecraft:composite`, от `2` до `12` слоёв, по умолчанию `6`). | `/wardrobe buildheadpack 6` |

### Диагностика, списки и обслуживание

| Команда | Описание |
| :--- | :--- |
| `/wardrobe layers` | Выводит текущий порядок всех 2D-слоёв сверху вниз (из `priority.yml` + `layers.yml`) с их папками, пометками `[ВЕРХНИЙ]`/`[НИЖНИЙ]`/`[BASE]` и алиасами. |
| `/wardrobe list` | Показывает загруженные PNG-текстуры из `plugins/MythicWardrobe/overlays/` (первые 40 ключей + общий счётчик). |
| `/wardrobe prewarm` | Запускает фоновый прогрев кэша базовых скинов (`body_skin` × `slim`/`wide`) через MineSkin API v2, чтобы игроки получали скины мгновенно. |
| `/wardrobe reload` | Перезагружает все 10 конфигов, `overlays/`, `head_composite_manifest.json`, кэш скиллов MythicMobs и обновляет визуал всех онлайн-игроков. |
| `/wardrobe debug [игрок]` | Выводит полную диагностику: активный Skin Backend, статус PacketEvents, `BodyType`, режим меню, базовый скин, активные 2D-слои в Z-порядке, заблокированные слоты/слои, содержимое кастомных слотов, число активных 3D-дисплеев и SHA-хэш последнего скина. |
