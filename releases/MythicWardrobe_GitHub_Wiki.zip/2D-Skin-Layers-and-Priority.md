# 2D-слои скина и приоритет наложения

Система 2D-слоёв MythicWardrobe накладывает прозрачные текстуры **PNG 64×64** поверх базового скина игрока в строго заданном порядке, формирует единый скин, подписывает его через MineSkin v2 (или кэш SQLite) и применяет через **SkinsRestorer v15** (или Paper API).

---

## Расширяемые слои (`layers.yml`)

Вы можете добавлять **любые новые категории слоёв** прямо в `plugins/MythicWardrobe/layers.yml` (например, `tattoos`, `makeup`, `blood`, `clan_patch`, `wings_2d`). После `/wardrobe reload`:
1. Автоматически создастся папка `plugins/MythicWardrobe/overlays/<folder>/`.
2. Новый слой сразу станет доступен в `/wardrobe set`, `/wardrobe clear`, Tab-автодополнении, встроенном веб-редакторе и в механиках MythicMobs (`- wardrobe{type=<id>;texture=...}`).

### 15 встроенных слоёв по умолчанию

| ID слоя | Папка `overlays/` | `replaces-base-skin` | Очистка 2-го слоя (`clear-outer-regions`) | Алиасы |
| :--- | :--- | :---: | :--- | :--- |
| `body_skin` | `body_skin/` | **Да** | — | `body`, `bodyskin`, `skin_color`, `skin` |
| `eyes` | `eyes/` | Нет | — | `eye` |
| `eyebrows` | `eyebrows/` | Нет | — | `brows` |
| `hair` | `hairs/` | Нет | — | `hairs`, `hairstyle` |
| `beard` | `beards/` | Нет | — | `beards`, `facial_hair` |
| `scars` | `scars/` | Нет | — | `tattoos`, `markings` |
| `pants` | `pants/` | Нет | `RIGHT_LEG_OUTER`, `LEFT_LEG_OUTER` | `legs`, `trousers` |
| `belt_skin` | `belts/` | Нет | — | `belt`, `waist_skin`, `sash` |
| `undershirt` | `undershirts/` | Нет | `BODY_OUTER`, `RIGHT_ARM_OUTER`, `LEFT_ARM_OUTER` | `tshirt`, `shirt`, `underwear_top` |
| `socks` | `socks/` | Нет | — | — |
| `jacket` | `jackets/` | Нет | `BODY_OUTER`, `RIGHT_ARM_OUTER`, `LEFT_ARM_OUTER` | `coat`, `hoodie`, `shirts` |
| `boots_skin` | `boots/` | Нет | — | `boots`, `shoes` |
| `gloves` | `gloves/` | Нет | — | — |
| `mask_skin` | `masks/` | Нет | — | `mask` |
| `hat` | `hats/` | Нет | — | `hats`, `headwear` |

### Параметры одного слоя в `layers.yml`

```yaml
layers:
  tattoos:
    priority: 13
    folder: "tattoos"
    replaces-base-skin: false
    clear-outer-regions: []
    aliases: ["tattoo", "ink"]
```

- **`priority`** — базовый приоритет (если слой не перечислен в `priority.yml`: чем больше число, тем выше рисуется).
- **`folder`** — имя подпапки внутри `plugins/MythicWardrobe/overlays/`.
- **`replaces-base-skin`** — если `true`, слой полностью заменяет оригинальный скин игрока (используется для `body_skin` — цвета кожи/тела).
- **`clear-outer-regions`** — зоны 2-го слоя (outer layer) базового скина, которые очищаются перед рисованием одежды, чтобы «родная» одежда со скина игрока не просвечивала:
  - `HEAD_OUTER`
  - `BODY_OUTER`
  - `RIGHT_ARM_OUTER`
  - `LEFT_ARM_OUTER`
  - `RIGHT_LEG_OUTER`
  - `LEFT_LEG_OUTER`
  - `ALL_OUTER`
- **`aliases`** — короткие названия для команд, `priority.yml` и MythicMobs.

---

## Порядок слоёв сверху вниз (`priority.yml`)

Чтобы не считать вручную числовые приоритеты, используйте `plugins/MythicWardrobe/priority.yml`. **Чем выше строка в списке `order`, тем ПОВЕРХ остальных рисуется слой:**

```yaml
order:
  - hat         # самый верхний слой (2D-шапка)
  - mask        # 2D-маска поверх лица и волос
  - hair        # 2D-причёска
  - brows       # брови
  - eyes        # глаза
  - beard       # борода / усы
  - gloves      # перчатки
  - jacket      # верхняя одежда (куртка / кофта / химзащита)
  - undershirt  # нижняя одежда (футболка / майка)
  - belt        # 2D-пояс / ремень / кушак (поверх штанов!)
  - boots_skin  # 2D-ботинки
  - pants       # штаны
  - socks       # носки
  - scars       # шрамы / татуировки
  - body        # самый нижний базовый слой кожи/тела (body_skin)
```

В `order` можно писать как точные ID (`mask_skin`, `eyebrows`, `body_skin`), так и алиасы (`mask`, `brows`, `body`, `belt`). Проверить итоговый порядок на сервере можно командой `/wardrobe layers`.

---

## Базовый скин (`body_skin`) и переключение рук (`slim` / `wide`)

Игрок или серверный скрипт может переключать тип модели рук между **Wide (Steve, 4px)** и **Slim (Alex, 3px)**:

- Команда игрока: `/wardrobe bodytype slim` · `/wardrobe bodytype wide` · `/wardrobe bodytype auto`
- Механика MythicMobs: `- wardrobe{bodytype=slim} @self` или `- wardrobe{type=body_skin;texture=light.png;bodytype=slim} @self`
- Условие MythicMobs: `- hasbodytype{type=slim} true`

### Подпапки `slim/` и `wide/` для текстур рук

Для любых слоёв, затрагивающих руки (`body_skin`, `undershirts`, `jackets`, `gloves` и ваши собственные), положите две версии файла с одинаковым именем в подпапки `slim/` и `wide/`:

```text
plugins/MythicWardrobe/overlays/jackets/
├── wide/
│   └── leather_brown.png   (широкие руки 4px)
└── slim/
    └── leather_brown.png   (узкие руки 3px)
```

В конфигах, командах и скиллах всегда пишите просто `leather_brown.png` (или `jackets/leather_brown.png`) — MythicWardrobe **сам** выберет нужный файл под текущий `bodytype` игрока!

### Резервные базовые скины (`base_skins/`)

На offline-серверах (или если у игрока нет текстуры скина) используются файлы из `plugins/MythicWardrobe/base_skins/`:
- `default_classic.png` (для `CLASSIC` / `wide`)
- `default_slim.png` (для `SLIM` / `slim`)

Если на игроке надет слой `body_skin`, он полностью перекрывает базовый скин.

---

## Встроенный стартовый набор (68 PNG)

При первом запуске (`skin.create-example-overlays: true`) в `plugins/MythicWardrobe/overlays/` создаются **68 готовых 64×64 PNG-текстур** — минимум по 2 варианта для каждой из 15 категорий (включая `slim/` и `wide/` варианты, 5 ремней в `belts/` и цельный костюм `hazmat_suit.png` в `jackets/`). Полный список см. в [Каталоге тестового пака](Test-Pack-Catalog).
