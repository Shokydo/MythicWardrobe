### MythicWardrobe Wiki

**Начало работы**
* [Главная](Home)
* [Установка и быстрый старт](Installation-and-Quick-Start)
* [Команды и права](Commands-and-Permissions)

**2D-скины и слоты**
* [2D-слои скина и приоритет](2D-Skin-Layers-and-Priority)
* [Разделы и слоты экипировки](Slots-and-Equipment)
* [Блокировка слоёв и слотов](Layer-and-Slot-Blocking)

**3D-броня и косметика**
* [3D-броня и MythicArmors](3D-Armor-and-MythicArmors)
* [Мультимодальная косметика (v1.10)](Multimodal-Cosmetics)
* [3D-причёски и шлемы](3D-Hairstyles-and-Helmets)

**Интерфейс и интеграции**
* [Меню и GUI (menus.yml)](Menus-and-GUI)
* [Интеграция MythicMobs и Crucible](MythicMobs-Integration)
* [MineSkin v2 и ускорение скинов](MineSkin-and-Performance)

**Инструменты и справочники**
* [MythicWardrobe Studio и веб-редактор](MythicWardrobe-Studio-and-Web-Editor)
* [Каталог тестового пака (21 модель)](Test-Pack-Catalog)
* [Справочник конфигов и FAQ](Configuration-Reference)

---
**Ссылки**
* [Репозиторий](https://github.com/Shokydo/MythicWardrobe)
* [Релизы (JAR + паки)](https://github.com/Shokydo/MythicWardrobe/releases)
* [Studio онлайн (GitHub Pages)](https://shokydo.github.io/MythicWardrobe/)
