# 3D-причёски и поведение под шлемами (`hair-3d.yml`)

MythicWardrobe поддерживает полноценные **3D-причёски MythicArmors** с:
- автоматической привязкой 3D-волос к выбранным 2D-волосам игрока;
- перекраской через `_t.png` (опционально — для готовых цветных моделей `color:` не нужен);
- полным или частичным отключением / подменой 3D-модели при надевании шлема или 2D-шапки;
- гибкими списками шлемов (`ALL`, `WHITELIST`, `BLACKLIST`) и исключений (`exceptions`).

---

## Как работают 3D-причёски

В `plugins/MythicWardrobe/hair-3d.yml` есть **две секции**:

1. **`bindings:`** — привязка 2D-текстуры из `overlays/hairs/` к 3D-предмету. Как только игрок выбирает эту 2D-причёску (через `/wardrobe set hair ...`, веб-редактор или скилл MythicMobs), 3D-причёска надевается **автоматически**.
2. **`items:`** — правила поведения под шлемом для 3D-причёсок, которые игрок положил **вручную** в слот `hair_3d`.

Если `manual-slot-overrides-binding: true` (по умолчанию), предмет, вручную положенный игроком в слот `hair_3d`, приоритетнее автопривязки из `bindings:`.

---

## Режимы поведения под шлемом (`helmet-mode`)

| Режим | Описание | Когда использовать |
| :--- | :--- | :--- |
| **`SWAP_MODEL`** | Просто подменяет текущую 3D-модель волос на другую готовую модель из `helmet-model:` (без `color:` и без обрезки кубов!). | Когда у вас есть 2 готовые модели: обычная причёска и примятая/укороченная модель под шлем. |
| **`PARTIAL_MODEL`** | Синоним `SWAP_MODEL` — подменяет на частичную модель из `helmet-partial-item:` (или `helmet-model:`). | Например, причёска с высоким хвостом + передними прядями: под шлемом хвост скрывается, а передние свисающие пряди остаются видны (`HairPonytail3D_HelmetSafe`). |
| **`HIDE_ALL`** | Полностью скрывает 3D-причёску, пока надет шлем. | Для объёмных причёсок (колючки, каре), которые торчали бы сквозь шлем. |
| **`KEEP`** | Оставляет 3D-причёску без изменений даже под шлемом. | Для плоских/прилегающих причёсок или аксессуаров. |

---

## Списки шлемов (`helmet-list-mode`, `helmets`, `exceptions`)

| Режим `helmet-list-mode` | Как проверяется надетый шлем |
| :--- | :--- |
| **`ALL`** *(по умолчанию)* | **Любой** шлем (реальный, косметический или 2D-шапка при `trigger-on-2d-hat: true`) вызывает реакцию, **кроме** перечисленных в `exceptions:`. |
| **`WHITELIST`** | Реакция срабатывает **только** для шлемов из списка `helmets:` (минус `exceptions:`). |
| **`BLACKLIST`** | Реакция срабатывает для всех шлемов, **кроме** перечисленных в `helmets:` и `exceptions:`. |

### Формат записей в `helmets:` и `exceptions:`
- **MythicMobs ID шлема:** `"TacticalWardenHelmet"`, `"GoldWardenHelmetCosmetic"`, `"Crown*"`
- **Ванильный материал или маска:** `"IRON_HELMET"`, `"*_HELMET"`
- **2D-шапка из слоя `hat`:** `"hat:beanie_grey.png"` или `"hat:*"`

---

## Полный пример `plugins/MythicWardrobe/hair-3d.yml`

```yaml
enabled: true
manual-slot-overrides-binding: true
trigger-on-2d-hat: true

default-helmet-list-mode: ALL
default-helmets: []
default-exceptions:
  - "SunglassesHelmet"
  - "RoyalCrown"

# 1. Автопривязка 2D-волос -> 3D-причёска
bindings:
  hair_brown.png:
    mythic-item: "HairSpiky3D_Dark"
    # color: опционален! Нужен только если модель использует _t.png на LEATHER_HELMET
    color: "135,78,52"
    helmet-mode: HIDE_ALL
    helmet-list-mode: ALL
    helmets: []
    exceptions: []

  hair_blonde.png:
    mythic-item: "HairPonytail3D_Chestnut"
    color: "225,192,110"
    # Под шлемом просто подменяется на HairPonytail3D_HelmetSafe (только передние пряди!)
    helmet-mode: PARTIAL_MODEL
    helmet-partial-item: "HairPonytail3D_HelmetSafe"
    helmet-list-mode: ALL
    helmets: []
    exceptions: []

  # Пример простой замены модели БЕЗ покраски (готовые цветные текстуры):
  silver_long.png:
    mythic-item: "MyCustomLongHair3D"
    helmet-mode: SWAP_MODEL
    helmet-model: "MyCustomLongHairUnderHelmet3D"
    helmet-list-mode: WHITELIST
    helmets:
      - "TacticalWardenHelmet"
      - "*_HELMET"
    exceptions: []

# 2. Правила для вручную надетых 3D-причёсок в слоте `hair_3d`
items:
  HairPonytail3D_Chestnut:
    helmet-mode: PARTIAL_MODEL
    helmet-partial-item: "HairPonytail3D_HelmetSafe"
    helmet-list-mode: ALL

  HairSpiky3D_Dark:
    helmet-mode: HIDE_ALL
    helmet-list-mode: ALL
```

> **Подсказка:** в [MythicWardrobe Studio](MythicWardrobe-Studio-and-Web-Editor) есть готовый визуальный редактор `hair-3d.yml`, где можно сразу привязать 2D-волосы к `.bbmodel`, выбрать модель под шлем и проверить её в окне **«Осмотр 2D+3D»**!
