# MineSkin API v2, кэширование и ускорение скинов

Клиент Minecraft в `online-mode` принимает только скины с криптографической RSA-подписью Mojang (`value` + `signature`). MythicWardrobe использует многоуровневую систему ускорения, чтобы скины собирались и применялись максимально быстро.

---

## Как устроен конвейер скинов

1. **Объединение изменений (`rebuild-debounce-ticks: 8`):** если игрок быстро переодел 3 вещи подряд (футболку + куртку + штаны), плагин ждёт `0.4 сек` и делает **один** композитный PNG вместо трёх запросов в API.
2. **Детерминированный SHA-256 кэш в SQLite (`plugins/MythicWardrobe/wardrobe.db`):** каждая уникальная комбинация «базовый скин + слои + bodytype» кэшируется **навсегда**. Повторное надевание той же комбинации любым игроком занимает **0 мс** (без единого запроса в интернет!).
3. **Фоновая сборка без закрытия GUI (`defer-apply-while-gui-open: true`):** пока игрок выбирает одежду в меню, скин уже подписывается в фоне и применяется мгновенно при закрытии меню.
4. **Параллельные запросы MineSkin API v2 (`POST /v2/generate`):** поддерживаются одновременные загрузки (`max-concurrency: 4`) и автоматический опрос очереди `/v2/queue/{id}` с повторными попытками при временных лимитах.

---

## Рекомендуемая настройка MineSkin API v2 (`config.yml`)

```yaml
mineskin:
  api-key: "ВАШ_КЛЮЧ_С_ACCOUNT_MINESKIN_ORG"
  base-url: "https://api.mineskin.org"
  user-agent: "MythicWardrobe/1.10"
  visibility: "unlisted"
  max-concurrency: 4
  timeout-seconds: 45
  poll-interval-ms: 700
  rebuild-debounce-ticks: 8
```

### Получение бесплатного API-ключа
1. Перейдите на [account.mineskin.org/keys](https://account.mineskin.org/keys).
2. Создайте API-ключ и вставьте его в `mineskin.api-key`.
3. Выполните `/wardrobe reload`.

> Без API-ключа MineSkin искусственно держит ~6 секунд задержки на каждый новый скин. С ключом скорость возрастает в 3–5 раз.

---

## Фоновый прогрев кэша (`/wardrobe prewarm`)

После запуска сервера или добавления новых базовых тонов кожи (`body_skin`) выполните:

```text
/wardrobe prewarm
```

Плагин в фоне заранее сгенерирует и сохранит в SQLite подписанные варианты базовых скинов (`body_skin` × `slim` / `wide`), чтобы новые игроки не ждали первой подписи.

---

## Приватный Self-Hosted Skin Signer (`tools/selfhosted_skin_signer.py`)

Для крупных серверов с большим онлайном, где публичных лимитов MineSkin недостаточно, в репозитории есть готовый локальный сервер подписи **`tools/selfhosted_skin_signer.py`** (на чистом Python stdlib — без внешних библиотек!).

Он полностью совместим с протоколом **MineSkin v2 `/v2/generate`**, кэширует все скины на диск (`signer_cache.json`) и подписывает новые скины через пул **ваших собственных лицензионных аккаунтов Minecraft Java**.

### Запуск
1. Создайте `accounts.json` рядом со скриптом:
   ```json
   [
     {
       "name": "SignerBot1",
       "uuid": "32-значный-uuid-без-дефисов",
       "access_token": "Bearer-токен Minecraft Services"
     }
   ]
   ```
2. Запустите сервер:
   ```bash
   python3 tools/selfhosted_skin_signer.py --host 127.0.0.1 --port 8088 --accounts accounts.json
   ```
3. Укажите локальный адрес в `plugins/MythicWardrobe/config.yml`:
   ```yaml
   mineskin:
     api-key: "YOUR_OPTIONAL_LOCAL_SECRET"
     base-url: "http://127.0.0.1:8088"
   ```

---

## Бэкенды применения скина (`skin.backend`)

| Значение | Поведение |
| :--- | :--- |
| **`AUTO`** *(по умолчанию)* | Использует **SkinsRestorer v15**, если установлен; иначе переключается на нативный **Paper PlayerProfile API**. |
| **`SKINSRESTORER`** | Принудительно только через SkinsRestorer v15 (поддерживает автоматическую пересборку одежды при смене базового скина командой `/skin <ник>` при `reapply-on-base-skin-change: true`). |
| **`PAPER`** | Напрямую через Paper API (не требует SkinsRestorer). |
