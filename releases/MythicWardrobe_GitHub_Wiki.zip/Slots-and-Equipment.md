# Разделы и слоты экипировки

Все слоты гардероба настраиваются в `plugins/MythicWardrobe/slots.yml` и сгруппированы по **4 разделам брони**: `HEAD`, `CHEST`, `LEGS`, `FEET`.

---

## Типы слотов (`SlotKind`)

| Тип (`kind`) | Как работает | Примеры слотов |
| :--- | :--- | :--- |
| `SKIN_LAYER` | 2D-слой скина (PNG 64×64 из `overlays/<folder>/`). При изменении пересобирает скин игрока. | `hat`, `mask_skin`, `undershirt`, `jacket`, `gloves`, `pants`, `belt_skin`, `socks`, `boots_skin` |
| `ARMOR_REAL` | Синхронизируется с реальным ванильным слотом брони игрока — даёт защиту, чары, атрибуты и `~onEquip`. | `helmet_real`, `chest_real`, `legs_real`, `boots_real` |
| `ARMOR_COSMETIC` | Перекрывает внешний вид реальной брони без потери её характеристик. Поддерживает обычную 3D-броню и [Мультимодальную косметику](Multimodal-Cosmetics). | `helmet_cosmetic`, `chest_cosmetic`, `legs_cosmetic`, `boots_cosmetic` |
| `DISPLAY_3D` | Одновременная 3D-модель поверх основной брони: для MythicArmors создаёт синхронизированный 3D-слой (или использует `combo-overrides.yml` / `head_composite`), для обычных 3D-предметов — `ItemDisplay`. | `mask_3d`, `backpack_3d` |
| `ARMOR_OVERLAY` | Дополнительный слой 3D-брони MythicArmors (можно добавлять сколько угодно слотов на голову, торс, пояс или ноги). | `hair_3d`, `belt_3d` |

> **Ключевое правило независимости:** КАЖДЫЙ слот полностью самостоятелен. Можно надеть `mask_3d` без шлема, `backpack_3d` без нагрудника, `belt_3d` без поножей, `hair_3d` без шлема — ни один предмет не зависит от наличия другого!

---

## Все 21 раздельный слот по умолчанию (`slots.yml` v1.11.0)

### Раздел `HEAD` — Голова и Шлем (6 слотов)
| ID слота | Тип (`kind`) | `equipment-slot` | Папка / Крепление | Назначение |
| :--- | :--- | :---: | :--- | :--- |
| `hat` | `SKIN_LAYER` | — | `overlays/hats/` | 2D-шапка / головной убор на скин |
| `mask_skin` | `SKIN_LAYER` | — | `overlays/masks/` | 2D-маска / бандана / балаклава на скин |
| `hair_3d` | `ARMOR_OVERLAY` | `HEAD` | `mount: HEAD` | 3D-причёска MythicArmors (поддерживает покраску и [hair-3d.yml](3D-Hairstyles-and-Helmets)) |
| `mask_3d` | `DISPLAY_3D` | — | `mount: HEAD` | 3D-маска / противогаз поверх шлема или отдельно |
| `helmet_real` | `ARMOR_REAL` | `HEAD` | Ванильный `HEAD` | Реальный 3D/ванильный шлем (защита, статы, чары) |
| `helmet_cosmetic` | `ARMOR_COSMETIC` | `HEAD` | Ванильный `HEAD` | Косметический 3D-скин/модель шлема |

### Раздел `CHEST` — Торс и Нагрудник (6 слотов)
| ID слота | Тип (`kind`) | `equipment-slot` | Папка / Крепление | Назначение |
| :--- | :--- | :---: | :--- | :--- |
| `undershirt` | `SKIN_LAYER` | — | `overlays/undershirts/` | Нижний 2D-слой одежды (футболка / майка) |
| `jacket` | `SKIN_LAYER` | — | `overlays/jackets/` | Верхний 2D-слой (куртка / кофта / цельный костюм с `Blocks`) |
| `gloves` | `SKIN_LAYER` | — | `overlays/gloves/` | 2D-перчатки на кисти рук |
| `chest_real` | `ARMOR_REAL` | `CHEST` | Ванильный `CHEST` | Реальный 3D/ванильный нагрудник / бронежилет (статы) |
| `chest_cosmetic` | `ARMOR_COSMETIC` | `CHEST` | Ванильный `CHEST` | Косметический нагрудник или мультимодальная краска (`WhiteVestPaint`) |
| `backpack_3d` | `DISPLAY_3D` | — | `mount: BACK` | 3D-рюкзак или дополнительный 3D-слой нагрудника |

### Раздел `LEGS` — Ноги, Штаны и Пояс (5 слотов)
| ID слота | Тип (`kind`) | `equipment-slot` | Папка / Крепление | Назначение |
| :--- | :--- | :---: | :--- | :--- |
| `pants` | `SKIN_LAYER` | — | `overlays/pants/` | 2D-штаны / джинсы / тактические брюки |
| `belt_skin` | `SKIN_LAYER` | — | `overlays/belts/` | 2D-пояс / ремень / кушак (рисуется поверх штанов) |
| `legs_real` | `ARMOR_REAL` | `LEGS` | Ванильный `LEGS` | Реальные 3D/ванильные поножи (статы) |
| `legs_cosmetic` | `ARMOR_COSMETIC` | `LEGS` | Ванильный `LEGS` | Косметические 3D-поножи |
| `belt_3d` | `ARMOR_OVERLAY` | `LEGS` | `mount: WAIST` | 3D-пояс, подсумки, кобура, цепи, колбы (отдельно или с поножами) |

### Раздел `FEET` — Ботинки и Обувь (4 слота)
| ID слота | Тип (`kind`) | `equipment-slot` | Папка / Крепление | Назначение |
| :--- | :--- | :---: | :--- | :--- |
| `socks` | `SKIN_LAYER` | — | `overlays/socks/` | 2D-носки (под ботинками) |
| `boots_skin` | `SKIN_LAYER` | — | `overlays/boots/` | 2D-обувь / кроссовки / берцы |
| `boots_real` | `ARMOR_REAL` | `FEET` | Ванильный `FEET` | Реальные 3D/ванильные ботинки (статы; старый алиас `belt_real` поддерживается) |
| `boots_cosmetic` | `ARMOR_COSMETIC` | `FEET` | Ванильный `FEET` | Косметические 3D-ботинки (старый алиас `belt_cosmetic` поддерживается) |

---

## 3 способа привязать предмет к слоту гардероба

MythicWardrobe проверяет все три источника метаданных предмета:

### Способ 1. Команда в игре (PDC-тег на самом предмете)
Возьмите любой предмет в основную руку и выполните:
```text
/wardrobe tag jacket jackets/leather_brown.png
/wardrobe tag backpack_3d
/wardrobe tag jacket hazmat_suit.png suit,mask_skin,hat UNEQUIP
```
Работает даже без MythicMobs!

### Способ 2. Прямо внутри YAML предмета MythicMobs (рекомендуется)
```yaml
WinterJacket:
  Material: LEATHER_CHESTPLATE
  Display: '&bЗимняя куртка'
  Wardrobe:
    Slot: jacket
    Texture: jackets/military_parka.png
    OnEquipSkill: ColdResistOn
    OnUnequipSkill: ColdResistOff
    Blocks: [undershirt]
    BlockMode: UNEQUIP
```
Поддерживается список нескольких слотов через запятую, например `Slot: chest_real,backpack_3d` (используется в `TacticalBackpackArmor`, чтобы 3D-рюкзак можно было положить и в `backpack_3d`, и в `chest_real`).

### Способ 3. Централизованно в `plugins/MythicWardrobe/items.yml`
```yaml
items:
  Example_Tactical_Backpack:
    slot: backpack_3d
    display-override:
      mount: BACK
      offset-y: 1.15
      offset-z: -0.28
      scale-x: 1.05
      scale-y: 1.05
      scale-z: 1.05
```

---

## Удобная экипировка и триггеры инвентаря (`config.yml`)

```yaml
inventory-trigger:
  enabled: true
  click-mode: "EMPTY_OR_RIGHT"   # EMPTY_OR_RIGHT | ALWAYS | RIGHT_CLICK_ONLY
  smart-cursor-equip: true       # Клик с одеждой на курсоре по слоту брони сразу надевает её в нужный слот
  right-click-quick-equip: true  # ПКМ 2D-одеждой в воздухе надевает её мгновенно (право mythicwardrobe.quickequip)
  disable-hand-right-click-armor-equip: true  # ЗАПРЕТИТЬ надевать броню (ванильную и 3D MythicArmors) через ПКМ в руке (обход: mythicwardrobe.bypass.handequip)

death:
  keep-wardrobe-items-on-death: true  # Сохранять вещи в доп. слотах гардероба при смерти
```

- **Smart Cursor Equip:** если вы держите на курсоре, например, 2D-куртку или `WhiteVestPaint` и кликаете по ванильному слоту нагрудника в инвентаре — предмет сразу попадёт в `jacket` или `chest_cosmetic` без лишнего открытия меню.
- **Right-Click Quick Equip:** ПКМ в воздухе с предметом одежды, 3D-аксессуара или мультимодальной краски в руке мгновенно надевает его в подходящий слот (если слот свободен или с обменом).
- **Сохранение при смерти:** при `keep-wardrobe-items-on-death: true` вещи в дополнительных слотах гардероба (футболки, куртки, косметика, рюкзаки, 3D-маски, 3D-пояса) остаются у игрока, а реальная броня в ванильных слотах подчиняется стандартному правилу `keepInventory` мира.
