# Блокировка слоёв и слотов (цельные костюмы)

Система блокировок позволяет настроить цельную одежду (например, **костюм химзащиты**, скафандр, комбинезон или плащ в слое `jacket`), которая **блокирует конфликтующие слои и слоты** — чтобы игрок не мог одновременно надеть штаны, другую футболку, ремень, перчатки или шапку поверх цельного костюма.

---

## Режимы блокировки (`BlockBehaviorMode`)

Глобальный режим по умолчанию задаётся в `config.yml` (`blocking.default-mode`), а каждый предмет может переопределять его своим `BlockMode` / `block-mode`:

| Режим | Поведение при надевании костюма | Поведение при попытке надеть вещь в заблокированный слот |
| :--- | :--- | :--- |
| **`UNEQUIP`** *(рекомендуется)* | Автоматически снимает мешающие вещи из конфликтующих слотов и возвращает их игроку в инвентарь (или дропает, если инвентарь полон), очищает конфликтующие 2D-слои скиллов. | Запрещено! В GUI слот отображается красным замком (`BARRIER`), блокируется перетаскивание, Shift-клик и ПКМ. |
| **`PREVENT`** | Не позволяет надеть костюм, пока игрок сам не снимет конфликтующие вещи, и пишет в чат список мешающих слотов. | Запрещено, пока надет блокирующий костюм. |
| **`HIDE`** | Оставляет надетые вещи лежать в их слотах, но блокирует редактирование этих слотов и полностью скрывает их визуально (и 2D-слои, и 3D-модели) до снятия костюма. | Запрещено, пока надет блокирующий костюм. |

---

## Групповые шорткаты целей блокировки

В списке `Blocks` (YAML, `items.yml`, команда `/wardrobe block`, механика `wardrobe{blocks=...}`) можно указывать как конкретные ID/алиасы слотов и слоёв (`pants`, `undershirt`, `belt_skin`, `mask_3d` и т.д.), так и готовые групповые шорткаты:

| Шорткат | Алиасы | Что блокирует |
| :--- | :--- | :--- |
| `all_body` | `suit`, `jumpsuit`, `full_body` | Все 2D-слои тела: `undershirt`, `pants`, `belt_skin`, `socks`, `gloves`, `boots_skin` |
| `all_clothing` | `clothing` | Все GUI-слоты типа `SKIN_LAYER` из `slots.yml` |
| `all_skin` | `skin` | Все 2D-слои из `layers.yml`, кроме базового `body_skin` |
| `all_3d` | `accessories`, `3d` | Все 3D-слоты (`DISPLAY_3D` / `ARMOR_OVERLAY`) |
| `all_cosmetic` | `cosmetic` | Все слоты косметической брони (`ARMOR_COSMETIC`) |
| `all` | `*` | Все слоты и все 2D-слои (кроме `body_skin`) |

> Сам слот, в который надет блокирующий предмет (например, `jacket`), автоматически исключается из списка блокируемых целей.

---

## 4 способа задать блокировку

### 1. Внутри MythicMobs Item YAML (пример: Костюм химзащиты)
```yaml
WardrobeHazmatSuit:
  Material: YELLOW_DYE
  Display: '&eКостюм химзащиты &7[Цельный]'
  Lore:
    - '&7Полностью закрывает тело, ноги, руки и голову'
    - '&cБлокирует: штаны, футболку, ремень, перчатки, обувь, маску, шапку'
  Wardrobe:
    Slot: jacket
    Texture: jackets/hazmat_suit.png
    Blocks:
      - undershirt
      - pants
      - belt_skin
      - gloves
      - socks
      - boots_skin
      - mask_skin
      - hat
    BlockMode: UNEQUIP
```

### 2. В `plugins/MythicWardrobe/items.yml`
```yaml
items:
  Example_Hazmat_Suit:
    slot: jacket
    texture: "jackets/hazmat_suit.png"
    blocks: [suit, mask_skin, hat]
    block-mode: UNEQUIP
```

### 3. В игре командой на предмет в руке
```text
/wardrobe block pants,undershirt,belt_skin,gloves,socks,boots_skin,mask_skin,hat UNEQUIP
/wardrobe block suit,mask_skin,hat PREVENT
/wardrobe block clear
```
Или сразу вместе с привязкой слота и текстуры:
```text
/wardrobe tag jacket hazmat_suit.png suit,mask_skin,hat UNEQUIP
```

### 4. Через механику MythicMobs (`wardrobe`)
```yaml
Skills:
  - wardrobe{type=jacket;texture=hazmat_suit.png;blocks=suit,mask_skin,hat} @self ~onEquip
  - unwardrobe{type=jacket} @self ~onUnequip
```
*(Если нужно принудительно наложить слой скиллом поверх блокировки, добавьте `force=true` в механику `wardrobe`.)*

---

## Очистка 2-го слоя базового скина (`inherit-clear-outer-regions`)

В `config.yml`:
```yaml
blocking:
  default-mode: "UNEQUIP"
  locked-slot-material: "BARRIER"
  inherit-clear-outer-regions: true
```

Когда `inherit-clear-outer-regions: true`, цельный костюм в слое `jacket`, блокирующий `pants` и `hat`, автоматически наследует их `clear-outer-regions` (`RIGHT_LEG_OUTER`, `LEFT_LEG_OUTER`, `HEAD_OUTER`). Благодаря этому ванильные штаны или шапка со 2-го слоя базового скина игрока **не будут торчать поверх костюма химзащиты**.
