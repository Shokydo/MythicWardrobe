# Интеграция с MythicMobs 5.13.0 и MythicCrucible

MythicWardrobe регистрирует в MythicMobs собственные **механики**, **условия**, парсит инлайн-блок **`Wardrobe:`** прямо из YAML предметов и автоматически запускает **`~onEquip` / `~onUnequip`** скиллы предметов при надевании/снятии в меню гардероба!

---

## 1. Механика `wardrobe` (наложение слоёв, `bodytype`, блокировки)

Алиасы механики: **`wardrobe`**, **`skinlayer`**, **`wardrobeskin`**

### Параметры

| Параметр | Алиасы | Описание |
| :--- | :--- | :--- |
| `type` | `slot`, `layer`, `category`, `s` | ID или алиас слоя из `layers.yml` (например `jacket`, `hair`, `body_skin`, `mask`, либо `bodytype`). Поддерживает MythicMobs-плейсхолдеры! |
| `texture` | `tex`, `file`, `overlay`, `value`, `t` | Имя PNG-файла из `overlays/` (или `none` / `clear` для снятия). |
| `bodytype` | `body_type`, `arms`, `armtype`, `model`, `variant` | Переключить руки игрока: `slim`, `wide` (или `classic`), `auto` (или `reset`/`default`). |
| `blocks` | `block`, `blockslots`, `blocklayers`, `lock`, `locked` | Список блокируемых слоёв/слотов через запятую (включая шорткаты `suit`, `all_clothing` и т.д.). |
| `action` | `mode`, `a` | `set` *(по умолчанию)*, `clear` (`remove`/`unwear`/`unset`), `reset` (`clearall`), `refresh` (`rebuild`/`apply`). |
| `immediate` | `now` | `true` — пересобрать скин немедленно без задержки `rebuild-debounce-ticks`. |
| `force` | `bypass`, `ignoreblocks` | `true` — наложить слой, игнорируя активные блокировки костюмов. |

### Примеры использования
```yaml
Skills:
  - wardrobe{type=jacket;texture=leather_brown.png} @self ~onEquip
  - wardrobe{type=jacket;texture=hazmat_suit.png;blocks=suit,mask_skin,hat} @self ~onEquip
  - wardrobe{type=body_skin;texture=pale_elf.png;bodytype=slim} @self
  - wardrobe{bodytype=wide} @self
  - wardrobe{type=jacket;action=clear} @self ~onUnequip
  - wardrobe{action=reset} @self
```

---

## 2. Механика `unwardrobe` (снятие слоёв для `~onUnequip`)

Алиасы механики: **`unwardrobe`**, **`removewardrobe`**, **`clearwardrobe`**, **`unwear`**, **`unskinlayer`**

Создана специально для чистого и безопасного снятия слоёв в `~onUnequip` (поддерживает проверку конкретной текстуры, чтобы снятие старой куртки случайно не стёрло уже надетую новую!).

### Параметры

| Параметр | Алиасы | Описание |
| :--- | :--- | :--- |
| `type` | `types`, `slot`, `layer`, `category`, `s` | Один слой (`jacket`), несколько слоёв через запятую (`jacket,undershirt,gloves`), или `all` / `*` *(по умолчанию `all`)*. |
| `texture` | `tex`, `file`, `overlay`, `only`, `t` | Если указано — снимет слой **ТОЛЬКО если** сейчас надета именно эта текстура! |
| `resetbodytype` | `reset_bodytype`, `clearbodytype`, `bodytype` | `true` — одновременно сбросить `bodytype` обратно в `auto`. |
| `immediate` | `now` | `true` — пересобрать скин немедленно. |

### Примеры
```yaml
Skills:
  - unwardrobe{type=jacket;texture=leather_brown.png} @self ~onUnequip
  - unwardrobe{type=jacket,undershirt,gloves} @self ~onUnequip
  - unwardrobe{type=body_skin;resetbodytype=true} @self ~onUnequip
  - unwardrobe{type=all} @self ~onUnequip
```

---

## 3. Условия (Conditions)

### `haswardrobelayer`
Алиасы: **`haswardrobelayer`**, **`wardrobelayer`**, **`wearingwardrobe`**

Проверяет наличие активного 2D-слоя ИЛИ предмета в любом кастомном слоте гардероба (`mask_3d`, `backpack_3d`, `belt_3d`, `chest_cosmetic` и т.д.).

```yaml
Conditions:
  - haswardrobelayer{type=jacket;texture=hazmat_suit.png} true
  - haswardrobelayer{type=mask_3d} true
  - haswardrobelayer{type=backpack_3d;item=TacticalBackpackArmor} true
```

### `hasbodytype`
Алиасы: **`hasbodytype`**, **`bodytype`**, **`wardrobebodytype`**

```yaml
Conditions:
  - hasbodytype{type=slim} true
  - hasbodytype{type=wide} true
```

---

## 4. Триггеры `~onEquip` и `~onUnequip` в меню гардероба (v1.9.2+)

Когда игрок надевает, снимает или заменяет одежду / 3D-аксессуар / косметическую броню в **любом слоте GUI гардероба** (или ПКМ / Smart Cursor / авто-снятием при блокировке костюмом), MythicWardrobe автоматически компилирует и запускает строки из стандартного блока **`Skills:`** предмета!

### Поддерживаемые имена триггеров
- **Надевание:** `~onEquip`, `~onEquipArmor`, `~onArmorEquip`, `~onWear`
- **Снятие:** `~onUnequip`, `~onUnEquip`, `~onUnequipArmor`, `~onArmorUnequip`, `~onUnwear`

### Пример предмета со скиллами на надевание и снятие
```yaml
RadiationHazmatJacket:
  Material: YELLOW_DYE
  Display: '&eЗащитный костюм'
  Wardrobe:
    Slot: jacket
    Texture: jackets/hazmat_suit.png
    Blocks: [suit, mask_skin, hat]
    BlockMode: UNEQUIP
  Skills:
    - potion{type=WATER_BREATHING;duration=999999;level=1;hasParticles=false} @self ~onEquip
    - sound{s=item.armor.equip_leather;v=1;p=1} @self ~onEquip
    - message{m="&aВы надели защитный костюм!"} @self ~onEquip
    - cure{type=WATER_BREATHING} @self ~onUnequip
    - message{m="&7Вы сняли защитный костюм."} @self ~onUnequip
```

### Настройки в `config.yml` и защита от дублирования с MythicCrucible
```yaml
mythicmobs:
  # Запускать ~onEquip / ~onUnequip для вещей в кастомных слотах гардероба
  trigger-item-equip-skills-in-gui: true
  # Если MythicCrucible НЕ установлен — запускать ~onEquip / ~onUnequip и для реальной брони в меню
  # (если MythicCrucible установлен, он обрабатывает реальную броню сам — двойного срабатывания не будет!)
  trigger-real-armor-equip-skills-without-crucible: true
```

---

## 5. Инлайн-блок `Wardrobe:` в MythicItem YAML

Все доступные ключи внутри `Wardrobe:` у любого предмета MythicMobs:

```yaml
MyItem:
  Material: LEATHER_CHESTPLATE
  Display: '&bПример предмета'
  Wardrobe:
    Slot: jacket                     # 1 слот или список через запятую ("chest_real,backpack_3d")
    Texture: jackets/demo.png        # для SKIN_LAYER
    OnEquipSkill: MyCustomSkillOn    # доп. имя MythicSkill (помимо стандартных Skills: ~onEquip)
    OnUnequipSkill: MyCustomSkillOff # доп. имя MythicSkill (помимо стандартных Skills: ~onUnequip)
    Blocks: [pants, undershirt]      # блокируемые слои/слоты или шорткаты (suit, all_clothing, ...)
    BlockMode: UNEQUIP               # UNEQUIP | PREVENT | HIDE
    Display:                         # опциональное переопределение 3D-крепления для ItemDisplay
      Mount: BACK                    # HEAD | BACK | WAIST
      OffsetX: 0.0
      OffsetY: 1.15
      OffsetZ: -0.26
      ScaleX: 1.0
      ScaleY: 1.0
      ScaleZ: 1.0
      RotX: 0.0
      RotY: 0.0
      RotZ: 0.0
      PitchFollow: false
      HideFromWearer: false
      Transform: HEAD
    # Для мультимодальной косметики (v1.10.0):
    UnmatchedMode: KEEP_REAL         # KEEP_REAL | FALLBACK_MODEL | USE_SELF
    EmptyArmorMode: KEEP_EMPTY       # KEEP_EMPTY | FALLBACK_MODEL | USE_SELF
    FallbackMythicItem: ""
    EmptyArmorMythicItem: ""
    Variants:
      LightMilitaryVest: LightMilitaryVest_White
      HeavyMilitaryVest: HeavyMilitaryVest_White
```
