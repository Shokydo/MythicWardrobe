# Каталог тестового пака (`MythicWardrobe_MythicArmors_TestPack.zip`)

Полный тестовый архив **`MythicWardrobe_MythicArmors_TestPack.zip`** включает в себя **21 готовую 3D-модель `.bbmodel`**, **43 предмета MythicMobs** (`MythicWardrobe_TestArmorPack.yml` + `MilitaryWhitePaint_Example.yml`) и готовые конфиги (`items.yml`, `combo-overrides.yml`, `hair-3d.yml`, `cosmetic-variants.yml`). Дополнительно в сам плагин встроены **68 стартовых 2D PNG-оверлеев**.

---

## 1. Все 21 3D-модель `.bbmodel` (`plugins/MythicArmors/models/`)

| № | Файл `.bbmodel` | Слот / Кости | Назначение |
| :-: | :--- | :--- | :--- |
| 1 | `tactical_warden.bbmodel` | Все 4 части | Боевая 3D-броня «Стража» (шлем, бронежилет, поножи, ботинки) |
| 2 | `gold_warden_cosmetic.bbmodel` | Все 4 части | Косметическая Золотая 3D-броня «Стража» |
| 3 | `tactical_gasmask.bbmodel` | `HEAD` (`head`) | Самостоятельный 3D-противогаз (носится без шлема или поверх него) |
| 4 | `tactical_backpack.bbmodel` | `CHEST` (`body`, `right_arm`, `left_arm`) | Самостоятельный 3D-рюкзак (носится без нагрудника или с ним) |
| 5 | `tactical_warden_masked.bbmodel` | `HEAD` | Комбо (0 лага): Тактический шлем + противогаз |
| 6 | `gold_warden_masked.bbmodel` | `HEAD` | Комбо (0 лага): Золотой шлем + противогаз |
| 7 | `tactical_warden_backpack.bbmodel` | `CHEST` | Комбо (0 лага): Тактический бронежилет + рюкзак |
| 8 | `gold_warden_backpack.bbmodel` | `CHEST` | Комбо (0 лага): Золотой бронежилет + рюкзак |
| 9 | `hair_spiky_3d.bbmodel` | `HEAD` (`_t.png`) | 3D-причёска «Взъерошенная» (перекрашиваемая) |
| 10 | `hair_ponytail_3d.bbmodel` | `HEAD` (`_t.png`) | 3D-причёска «Хвост» с резинкой и передними прядями |
| 11 | `hair_ponytail_3d_under_helmet.bbmodel` | `HEAD` (`_t.png`) | Частичный вариант «Хвост под шлемом» (хвост скрыт, передние пряди видны) |
| 12 | `hair_bob_3d.bbmodel` | `HEAD` (`_t.png`) | 3D-причёска «Каре» с заколкой |
| 13 | `belt_tactical_3d.bbmodel` | `LEGS` (`waist`, `right_leg`, `left_leg`) | 3D Тактический пояс с подсумками и набедренной кобурой |
| 14 | `belt_adventurer_3d.bbmodel` | `LEGS` | 3D Пояс искателя (сумка, светящаяся колба маны `_e`, свиток, кинжал) |
| 15 | `belt_chains_3d.bbmodel` | `LEGS` (`_t.png`) | 3D Королевский кушак + золотые цепи + рубин |
| 16 | `tactical_warden_belt.bbmodel` | `LEGS` | Комбо (0 лага): Тактические поножи + Тактический 3D-пояс |
| 17 | `gold_warden_belt.bbmodel` | `LEGS` | Комбо (0 лага): Золотые поножи + Королевский пояс с цепями |
| 18 | `light_military_vest.bbmodel` | `CHEST` (18 кубов) | Лёгкий военный бронежилет (олива/хаки, плитник JPC) |
| 19 | `light_military_vest_white.bbmodel` | `CHEST` (18 кубов) | Лёгкий военный бронежилет — **Белый арктический вариант** |
| 20 | `heavy_military_vest.bbmodel` | `CHEST` (31 куб) | Тяжёлый военный бронежилет (олива/хаки, джаггернаут с воротником и наплечниками) |
| 21 | `heavy_military_vest_white.bbmodel` | `CHEST` (31 куб) | Тяжёлый военный бронежилет — **Белый арктический вариант** |

---

## 2. Все 43 MythicMobs предмета (`plugins/MythicMobs/Items/`)

### Мультимодальная косметика (`MilitaryWhitePaint_Example.yml`)
| MythicMobs ID | Назначение | Команда выдачи |
| :--- | :--- | :--- |
| `LightMilitaryVest` | Реальный лёгкий военный бронежилет (+6 брони, +0.02 скорости) | `/mm i give @s LightMilitaryVest` |
| `HeavyMilitaryVest` | Реальный тяжёлый военный бронежилет (+10 брони, +4 прочности, +20% стойкости) | `/mm i give @s HeavyMilitaryVest` |
| `WhiteVestPaint` | **1 универсальная «Белая краска для бронежилета»** (`WHITE_DYE`, слот `chest_cosmetic`) | `/mm i give @s WhiteVestPaint` |
| `LightMilitaryVest_White` | Внутренний визуальный скин белого лёгкого жилета (подставляется автоматически) | `/mm i give @s LightMilitaryVest_White` |
| `HeavyMilitaryVest_White` | Внутренний визуальный скин белого тяжёлого жилета (подставляется автоматически) | `/mm i give @s HeavyMilitaryVest_White` |

### Боевая и косметическая 3D-броня (`MythicWardrobe_TestArmorPack.yml`)
- **Боевой сет «Стража»:** `TacticalWardenHelmet`, `TacticalWardenVest`, `TacticalWardenLeggings`, `TacticalWardenBoots`
- **Косметический Золотой сет:** `GoldWardenHelmetCosmetic`, `GoldWardenChestCosmetic`, `GoldWardenLegsCosmetic`, `GoldWardenBootsCosmetic`
- **Самостоятельные 3D-аксессуары:** `TacticalGasMask3D`, `TacticalBackpackArmor` (подходит для `backpack_3d` и `chest_real`), `TacticalBackpack3D`
- **3D-причёски:** `HairSpiky3D_Dark`, `HairSpiky3D_Blonde`, `HairSpiky3D_Crimson`, `HairPonytail3D_Chestnut`, `HairPonytail3D_Silver`, `HairPonytail3D_HelmetSafe`, `HairBob3D_Black`, `HairBob3D_Rose`
- **3D-пояса:** `TacticalUtilityBelt3D`, `AdventurerPouchBelt3D`, `RoyalChainBelt3D`
- **Комбо-модели (подставляются через `combo-overrides.yml`):** `TacticalWardenHelmetMasked`, `GoldWardenHelmetMasked`, `TacticalWardenVestBackpack`, `GoldWardenChestBackpack`, `TacticalWardenLegsWithBelt`, `GoldWardenLegsWithBelt`

### Предметы 2D-одежды, ремней и костюма с `Blocks` (`MythicWardrobe_TestArmorPack.yml`)
- **Одежда:** `WardrobeLeatherJacket`, `WardrobeBlueJeans`, `WardrobeCombatBoots`, `WardrobeRedBandana`
- **2D-ремни и пояса (слот `belt_skin`):** `WardrobeLeatherBelt`, `WardrobeTacticalBelt`, `WardrobeGoldChainBelt`, `WardrobeHolsterBelt`, `WardrobeCrimsonSash`
- **Цельный костюм с блокировкой слоёв (`Blocks`):** `WardrobeHazmatSuit` (слой `jacket`, блокирует `undershirt, pants, belt_skin, gloves, socks, boots_skin, mask_skin, hat` в режиме `UNEQUIP`)

---

## 3. Все 68 встроенных 2D-текстур (`plugins/MythicWardrobe/overlays/`)

| Категория (папка) | Кол-во | Файлы PNG (64×64) |
| :--- | :-: | :--- |
| `body_skin/` (`slim/` + `wide/`) | 10 | `dark.png`, `light.png`, `olive.png`, `pale_elf.png`, `tan.png` |
| `eyes/` | 5 | `amber.png`, `blue.png`, `brown.png`, `crimson.png`, `green.png` |
| `eyebrows/` | 2 | `dark_thick.png`, `light_arched.png` |
| `hairs/` | 5 | `black_messy.png`, `blonde_swept.png`, `brown_short.png`, `red_bob.png`, `silver_long.png` |
| `beards/` | 2 | `full_beard.png`, `goatee_dark.png` |
| `scars/` | 2 | `eye_scar.png`, `warpaint_blue.png` |
| `pants/` | 4 | `blue_jeans.png`, `cargo_olive.png`, `grey_joggers.png`, `tactical_black.png` |
| `belts/` | 5 | `crimson_sash.png`, `gold_chain_belt.png`, `leather_belt.png`, `tactical_belt.png`, `utility_holster_belt.png` |
| `undershirts/` (`slim/` + `wide/`) | 8 | `black_tshirt.png`, `olive_tank.png`, `striped_navy.png`, `white_tshirt.png` |
| `socks/` | 3 | `black_socks.png`, `striped_socks.png`, `white_socks.png` |
| `jackets/` (`slim/` + `wide/`) | 10 | `black_hoodie.png`, `hazmat_suit.png`, `leather_brown.png`, `military_parka.png`, `red_bomber.png` |
| `boots/` | 3 | `combat_boots.png`, `leather_boots.png`, `red_sneakers.png` |
| `gloves/` (`slim/` + `wide/`) | 4 | `leather_fingerless.png`, `tactical_black.png` |
| `masks/` | 3 | `balaclava_black.png`, `bandana_red.png`, `respirator.png` |
| `hats/` | 2 | `beanie_grey.png`, `ushanka_brown.png` |
