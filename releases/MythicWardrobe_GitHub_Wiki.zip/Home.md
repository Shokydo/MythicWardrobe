# MythicWardrobe — Полная документация (Wiki)

**MythicWardrobe** — модульная система гардероба, 2D-слоёв скина, косметической брони, 3D-аксессуаров и мультимодальных скинов для **Paper 1.21.8 – 1.21.11** с нативной интеграцией **MythicMobs 5.13.0**, **MythicArmors**, **MythicCrucible**, **SkinsRestorer v15** и **PacketEvents**.

> **Онлайн-конструктор 2D + 3D моделей и GUI:** [https://shokydo.github.io/MythicWardrobe/](https://shokydo.github.io/MythicWardrobe/)  
> **Скачать JAR, Тестовый 3D-пак и Studio:** [Releases](https://github.com/Shokydo/MythicWardrobe/releases)

---

## Что умеет MythicWardrobe (v1.11.0)

| Модуль | Описание | Страница Wiki |
| :--- | :--- | :--- |
| **2D-слои скина** | Неограниченное число расширяемых слоёв PNG 64×64 поверх базового скина, базовый цвет тела (`body_skin`), переключение рук `slim` / `wide`, наглядный приоритет в `priority.yml`, 68 готовых тестовых PNG. | [2D-слои скина и приоритет](2D-Skin-Layers-and-Priority) |
| **Слоты и экипировка** | **21 полностью отдельный слот** в 4 разделах (`HEAD` 6, `CHEST` 6, `LEGS` 5, `FEET` 4): 2D-слои, реальная 3D-броня (`*_real`), 3D-косметика (`*_cosmetic`) и 3D-аксессуары, умный клик по броне и запрет ПКМ-надевания брони из руки (`disable-hand-right-click-armor-equip: true`). | [Разделы и слоты экипировки](Slots-and-Equipment) |
| **Блокировка слоёв** | Цельные костюмы (например, костюм химзащиты в слое `jacket`) автоматически блокируют штаны, футболку, пояс, перчатки, шапку в режимах `UNEQUIP`, `PREVENT` или `HIDE`. | [Блокировка слоёв и слотов](Layer-and-Slot-Blocking) |
| **3D-броня и MythicArmors** | Независимое ношение любых 3D-моделей (маска без шлема, рюкзак без нагрудника, пояс без поножей), одновременное наложение нескольких 3D-моделей, комбо-склейка `/wardrobe merge`, безлимитные 3D-слои головы (`/wardrobe buildheadpack`). | [3D-броня и MythicArmors](3D-Armor-and-MythicArmors) |
| **Мультимодальная косметика** | **1 косметический предмет** (например, «Белая краска для бронежилета») адаптирует отображаемую 3D-модель под конкретную надетую реальную броню (лёгкий жилет → белый лёгкий, тяжёлый → белый тяжёлый, снят → скрыт). | [Мультимодальная косметика](Multimodal-Cosmetics) |
| **3D-причёски** | Автопривязка 3D-волос к выбранным 2D-волосам, покраска `_t.png`, автоматическое отключение или замена модели под шлемом (`SWAP_MODEL`, `PARTIAL_MODEL`, `HIDE_ALL`, `KEEP`). | [3D-причёски и шлемы](3D-Hairstyles-and-Helmets) |
| **Гибкие GUI-меню** | 3 переключаемых режима (`COMPACT` 1-строчный, `TABBED` с вкладками, `UNIFIED` общий), полная настройка заголовков, размеров, `CustomModelData` / `ItemModel`, кнопка «◀ Назад», отсутствие закрытия меню при смене скина. | [Меню и GUI](Menus-and-GUI) |
| **MythicMobs и Crucible** | Механики `wardrobe` и `unwardrobe`, условия `haswardrobelayer` и `hasbodytype`, автоматическое срабатывание триггеров `~onEquip` / `~onUnequip` в GUI-слотах гардероба, инлайн-секция `Wardrobe:` в предметах. | [Интеграция MythicMobs](MythicMobs-Integration) |
| **Ускорение скинов** | MineSkin API v2 (параллельные запросы + SQLite-кэш по SHA-256), прогрев `/wardrobe prewarm`, готовый приватный Self-Hosted Skin Signer (`tools/selfhosted_skin_signer.py`). | [MineSkin v2 и ускорение](MineSkin-and-Performance) |
| **Studio v2.6 + веб-редактор** | Автономный монохромный сайт **MythicWardrobe Studio v2.6** (все 21 раздельных слотов: реальная 3D-броня + 3D-косметика + 3D-аксессуары + 2D-скины, 20 демо-моделей, 10 экранов GUI `menus.yml`, 5 поз, 8 камер, 149 текстур MC 1.21.4) + временный серверный `/wardrobe web`. | [Studio и веб-редактор](MythicWardrobe-Studio-and-Web-Editor) |

---

## Быстрая навигация по файлам конфигурации

Все конфиги находятся в `plugins/MythicWardrobe/`:

| Файл | Назначение | Подробнее |
| :--- | :--- | :--- |
| `config.yml` | MineSkin v2, бэкенд скинов, клики по инвентарю, блокировки, 3D-дисплеи, смерть, триггеры, веб-редактор | [Справочник конфигов](Configuration-Reference) |
| `layers.yml` | Определение всех 2D-слоёв скина, папок `overlays/`, алиасов и зон очистки 2-го слоя | [2D-слои скина и приоритет](2D-Skin-Layers-and-Priority) |
| `priority.yml` | Наглядный порядок наложения 2D-слоёв сверху вниз (`hat` → `mask` → `hair` → ... → `body`) | [2D-слои скина и приоритет](2D-Skin-Layers-and-Priority) |
| `slots.yml` | Описание разделов (`HEAD`/`CHEST`/`LEGS`/`FEET`) и всех GUI-слотов (`SKIN_LAYER`, `ARMOR_REAL`, `ARMOR_COSMETIC`, `DISPLAY_3D`, `ARMOR_OVERLAY`) | [Разделы и слоты экипировки](Slots-and-Equipment) |
| `menus.yml` | Настройка всех 3 режимов GUI (`compact`, `tabbed`, `unified`), кнопок, декора, `CustomModelData` и `back-command` | [Меню и GUI](Menus-and-GUI) |
| `items.yml` | Привязка MythicMobs ID к слотам, текстурам, блокировкам, смещениям 3D и вариантам косметики | [Разделы и слоты экипировки](Slots-and-Equipment) |
| `combo-overrides.yml` | Опциональные правила подмены пары 3D-предметов на заранее склеенную комбо-модель (0 лага) | [3D-броня и MythicArmors](3D-Armor-and-MythicArmors) |
| `hair-3d.yml` | Автопривязка 2D-волос → 3D-причёски и правила скрытия/замены при надевании шлемов | [3D-причёски и шлемы](3D-Hairstyles-and-Helmets) |
| `cosmetic-variants.yml` | Мультимодальная косметика: 1 предмет меняет 3D-модель/цвет под конкретную надетую реальную броню | [Мультимодальная косметика](Multimodal-Cosmetics) |
| `messages.yml` | Все тексты чата, префикс и заголовки (MiniMessage + hex + `&-коды`) | [Справочник конфигов](Configuration-Reference) |

---

## Первые шаги

1. Прочитайте [Установку и быстрый старт](Installation-and-Quick-Start).
2. Установите `MythicWardrobe-1.10.0.jar` и распакуйте `MythicWardrobe_MythicArmors_TestPack.zip` (включает все 21 `.bbmodel`, 43 MythicMobs предмета и готовый пример мультимодальной краски для бронежилетов).
3. Выполните в игре:
   ```text
   /ma reload
   /mm reload
   /wardrobe reload
   ```
4. Изучите [Каталог тестового пака](Test-Pack-Catalog) и откройте гардероб командой `/wardrobe` или кликом по слоту брони в инвентаре.
