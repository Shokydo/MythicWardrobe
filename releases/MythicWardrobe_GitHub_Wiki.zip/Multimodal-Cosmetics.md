# Мультимодальная косметика (v1.10.0)

**Мультимодальная косметика** позволяет создать **один косметический предмет** (например, краску или камуфляж из `WHITE_DYE` / `PAPER`), который подходит сразу к разным видам реальной брони и **автоматически меняет 3D-модель или цвет в зависимости от того, какая реальная броня сейчас надета на игроке**.

---

## Как это работает на примере «Белой краски для бронежилета»

1. Игрок кладёт **1 предмет** `WhiteVestPaint` (обычный `WHITE_DYE`) в слот **`chest_cosmetic`** (через GUI, Smart Cursor клик по нагруднику или ПКМ в руке).
2. Реальный жилет меняется — косметика сама подстраивается мгновенно:
   - Надет `LightMilitaryVest` → отображается **`LightMilitaryVest_White`** (белый лёгкий плитник).
   - Игрок переодевает `HeavyMilitaryVest` (не трогая косметику!) → модель мгновенно меняется на **`HeavyMilitaryVest_White`** (белый тяжёлый джаггернаут).
   - Надета обычная `LEATHER_CHESTPLATE` → красит её в белый `#F5F5F5`.
   - Надет неизвестный алмазный нагрудник → `unmatched-mode: KEEP_REAL` оставляет его без изменений.
   - Жилет снят совсем → `empty-armor-mode: KEEP_EMPTY` ничего не рисует (краска не «надевается» на голое тело!).
3. Полностью работает в связке с `combo-overrides.yml` и `hair-3d.yml` (в пайплайне `ArmorVisualManager` мультимодальный резолвер выполняется **до** комбо-правил и проверки шлемов для 3D-волос).

---

## 3 способа настройки

### Способ 1. Файл `plugins/MythicWardrobe/cosmetic-variants.yml` (основной)

```yaml
enabled: true

skins:
  white_vest_paint:
    # MythicMobs ID косметического предмета (поддерживает список и маску *)
    cosmetic-item: "WhiteVestPaint"

    # В какие слоты ARMOR_COSMETIC разрешено класть этот предмет (даже если это WHITE_DYE!)
    allowed-slots:
      - "chest_cosmetic"

    # Поведение, если надета броня, не совпавшая ни с одним вариантом:
    #   KEEP_REAL      — оставить реальную броню как есть (рекомендуется для красок)
    #   FALLBACK_MODEL — показать fallback-mythic-item
    #   USE_SELF       — показать сам косметический предмет
    unmatched-mode: "KEEP_REAL"

    # Поведение, если реальная броня снята (пустой слот):
    #   KEEP_EMPTY     — ничего не показывать (рекомендуется для красок)
    #   FALLBACK_MODEL — показать empty-armor-mythic-item (или fallback-mythic-item)
    #   USE_SELF       — показать сам косметический предмет
    empty-armor-mode: "KEEP_EMPTY"
    fallback-mythic-item: ""
    empty-armor-mythic-item: ""

    # Варианты проверяются сверху вниз — срабатывает первый совпавший!
    variants:
      light_military_vest:
        match-armor:
          - "LightMilitaryVest"
          - "LightMilitaryVest_Mk2"
        result-mythic-item: "LightMilitaryVest_White"

      heavy_military_vest:
        match-armor:
          - "HeavyMilitaryVest"
          - "HeavyMilitaryVest_Mk2"
        result-mythic-item: "HeavyMilitaryVest_White"

      tactical_warden_chest:
        match-armor: ["TacticalWardenChestplate", "TacticalWardenVest"]
        dye-color: "#F2F4F8"

      vanilla_leather_chest:
        match-materials: ["LEATHER_CHESTPLATE"]
        dye-color: "#F5F5F5"
```

### Способ 2. Прямо внутри MythicMobs Item YAML (`Wardrobe.Variants`)

Поддерживается как короткая запись (`Броня: Результат`), так и полная структурированная:

```yaml
WhiteVestPaint:
  Material: WHITE_DYE
  Display: '&f&lБелая краска для бронежилета &7[Мульти-скин]'
  Options:
    HideFlags: true
  Wardrobe:
    Slot: chest_cosmetic
    UnmatchedMode: KEEP_REAL
    EmptyArmorMode: KEEP_EMPTY
    Variants:
      LightMilitaryVest: LightMilitaryVest_White
      HeavyMilitaryVest: HeavyMilitaryVest_White
```

### Способ 3. В `plugins/MythicWardrobe/items.yml`

```yaml
items:
  WhiteVestPaint:
    slot: chest_cosmetic
    unmatched-mode: KEEP_REAL
    empty-armor-mode: KEEP_EMPTY
    variants:
      LightMilitaryVest: LightMilitaryVest_White
      HeavyMilitaryVest: HeavyMilitaryVest_White
```

---

## Все параметры правила варианта (`VariantRule`)

### Условия сопоставления (проверяются по И — все указанные должны совпасть)

| Параметр | Описание | Примеры |
| :--- | :--- | :--- |
| `equipment-slot` | Ограничить вариант конкретным слотом (`HEAD`, `CHEST`, `LEGS`, `FEET`). Полезно для 1 универсальной краски на все 4 слота! | `CHEST`, `HEAD` |
| `match-armor` | MythicMobs ID реальной брони (поддерживает маску `*`). | `["LightMilitaryVest*"]` |
| `match-materials` | Ванильный `Material` реальной брони (поддерживает маску `*`). | `["LEATHER_CHESTPLATE", "*_CHESTPLATE"]` |
| `match-custom-model-data` | Список чисел `CustomModelData` реальной брони. | `[1001, 1002]` |
| `match-models` | Совпадение по `Equippable.Model` или `ItemModel` реальной брони (с маской `*`). | `["mythicarmor:light_military_vest*"]` |

### Результат визуала (что отобразить на игроке)

| Параметр | Описание | Примеры |
| :--- | :--- | :--- |
| `result-mythic-item` | Полная подмена визуала на готовый предмет MythicMobs / MythicArmors. | `"LightMilitaryVest_White"` |
| `dye-color` | Перекраска брони (HEX или `R,G,B`) — можно применять поверх реальной брони или поверх `result-mythic-item`. | `"#F5F5F5"`, `"240,245,250"` |
| `equippable-model` | Подмена `Equippable.Model` без создания отдельного MythicMobs-предмета. | `"mythicarmor:heavy_military_legs_winter"` |
| `item-model` | Подмена `ItemModel` (удобно для `HEAD` моделей). | `"mythicarmor:helmet_winter_head_piece"` |
| `custom-model-data` | Подмена `CustomModelData` на визуальной копии предмета. | `2040` |

---

## Пример: 1 универсальный скин сразу на все 4 слота брони

```yaml
skins:
  winter_camo_universal:
    cosmetic-item: "WinterCamoPaint"
    allowed-slots: ["helmet_cosmetic", "chest_cosmetic", "legs_cosmetic", "boots_cosmetic"]
    unmatched-mode: "KEEP_REAL"
    empty-armor-mode: "KEEP_EMPTY"
    variants:
      light_helmet:
        equipment-slot: HEAD
        match-armor: ["LightMilitaryHelmet"]
        result-mythic-item: "LightMilitaryHelmet_Winter"
      heavy_vest:
        equipment-slot: CHEST
        match-armor: ["HeavyMilitaryVest"]
        result-mythic-item: "HeavyMilitaryVest_White"
```

> **Безопасность слотов:** предметы, зарегистрированные в `cosmetic-variants.yml` или с `Wardrobe.Variants`, допускаются ТОЛЬКО в разрешённые `ARMOR_COSMETIC` слоты и **отклоняются** в `ARMOR_REAL`, чтобы игрок случайно не положил краску вместо боевой брони.
