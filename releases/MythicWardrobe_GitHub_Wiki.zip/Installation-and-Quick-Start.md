# Установка и быстрый старт

## Требования и зависимости

| Компонент | Версия | Обязательность | Назначение |
| :--- | :--- | :--- | :--- |
| **Сервер** | Paper **1.21.8 – 1.21.11** (Java 21) | Обязательно | Ядро сервера |
| **SkinsRestorer** | v15 (`15.10.2+`) | Рекомендуется | Применение подписанных скинов без разрыва визуала (иначе используется встроенный Paper API fallback) |
| **PacketEvents** | `2.11+` | Рекомендуется | Отображение косметической брони самому игроку в F5 (`cosmetic-armor.show-to-self: true`) |
| **MythicMobs** | `5.13.0+` | Опционально | Механики `wardrobe` / `unwardrobe`, условия, `Wardrobe:` в YAML предметов, триггеры `~onEquip` / `~onUnequip` |
| **MythicArmors** | Актуальная | Опционально | Генерация 3D-моделей брони, масок, рюкзаков, поясов и 3D-причёсок из `.bbmodel` |
| **MythicCrucible** | Актуальная | Опционально | Полная совместимость; плагин автоматически избегает двойного вызова `~onEquip` на реальной броне |

---

## Шаг 1. Установка плагина

1. Скачайте последний **`MythicWardrobe-1.10.0.jar`** из раздела [Releases](https://github.com/Shokydo/MythicWardrobe/releases).
2. Положите JAR в папку `plugins/` вашего Paper-сервера.
3. Запустите сервер один раз, чтобы в `plugins/MythicWardrobe/` создались все конфиги, папка `overlays/` и 68 стартовых тестовых PNG-текстур (15 категорий).

---

## Шаг 2. Настройка MineSkin API v2 (важно для скорости)

Откройте `plugins/MythicWardrobe/config.yml` и укажите бесплатный API-ключ MineSkin (получается на [account.mineskin.org/keys](https://account.mineskin.org/keys)):

```yaml
mineskin:
  api-key: "ВАШ_КЛЮЧ_MINESKIN"
  base-url: "https://api.mineskin.org"
  visibility: "unlisted"
  max-concurrency: 4
```

> **Почему это важно:** без API-ключа MineSkin искусственно задерживает каждый новый скин на ~6 секунд. С бесплатным ключом генерация ускоряется в 3–5 раз, а все уже собранные комбинации кэшируются в SQLite навсегда (`plugins/MythicWardrobe/wardrobe.db`). Подробнее про ускорение и приватный Self-Hosted Signer см. [MineSkin v2 и ускорение скинов](MineSkin-and-Performance).

---

## Шаг 3. Установка тестового 3D-пака (опционально, но рекомендуется)

Если вы используете **MythicArmors** и **MythicMobs**, скачайте **`MythicWardrobe_MythicArmors_TestPack.zip`** из [Releases](https://github.com/Shokydo/MythicWardrobe/releases):

1. Распакуйте архив **в корень сервера**, чтобы его папка `plugins/` слилась с вашей `plugins/`.
2. Убедитесь, что появились файлы:
   - `plugins/MythicArmors/models/*.bbmodel` — **21 готовая 3D-модель** (боевая и косметическая броня, противогаз, рюкзак, 3D-причёски, 3D-пояса, комбо-модели и 4 военных бронежилета).
   - `plugins/MythicMobs/Items/MythicWardrobe_TestArmorPack.yml` — 38 тестовых предметов.
   - `plugins/MythicMobs/Items/MilitaryWhitePaint_Example.yml` — 5 предметов примера мультимодальной косметики (`LightMilitaryVest`, `HeavyMilitaryVest`, `WhiteVestPaint`, `LightMilitaryVest_White`, `HeavyMilitaryVest_White`).
   - `plugins/MythicWardrobe/items.yml`, `combo-overrides.yml`, `hair-3d.yml`, `cosmetic-variants.yml`.
3. Выполните перезагрузку **строго в этом порядке**:
   ```text
   /ma reload
   /mm reload
   /wardrobe reload
   ```
4. Соберите объединённый ресурспак с поддержкой безлимитных 3D-слоёв головы (Minecraft 1.21.4+ `minecraft:composite`):
   ```text
   /wardrobe buildheadpack
   ```
5. Подключите ресурспак `plugins/MythicWardrobe/merged_pack.zip` (или `plugins/MythicArmors/pack.zip` / `output/`) к клиенту или серверу.

---

## Шаг 4. Быстрая проверка в игре

1. Откройте гардероб командой `/wardrobe` (или просто кликните по слоту брони в вашем обычном инвентаре).
2. Проверьте 2D-слои скина и смену рук:
   ```text
   /wardrobe bodytype slim
   /wardrobe set @s body_skin light.png
   /wardrobe set @s hair blonde_swept.png
   /wardrobe set @s jacket leather_brown.png
   ```
3. Проверьте 3D-броню и мультимодальную косметику:
   ```text
   /mm i give @s LightMilitaryVest
   /mm i give @s HeavyMilitaryVest
   /mm i give @s WhiteVestPaint
   ```
   Положите `WhiteVestPaint` в слот **«Нагрудник (Косметика)»**, а в реальный слот надевайте по очереди `LightMilitaryVest` и `HeavyMilitaryVest` — один предмет краски автоматически поменяет 3D-модель под каждый жилет!
4. Проверьте блокировку слоёв на цельном костюме:
   ```text
   /mm i give @s WardrobeBlueJeans
   /mm i give @s WardrobeHazmatSuit
   ```
5. Посмотрите полную диагностику игрока:
   ```text
   /wardrobe debug
   ```

---

## Порядок перезагрузки после изменений

- Поменяли `.bbmodel` → `/ma reload` → `/wardrobe buildheadpack` → обновить ресурспак.
- Поменяли файлы в `plugins/MythicMobs/Items/` → `/mm reload` → `/wardrobe reload`.
- Поменяли конфиги в `plugins/MythicWardrobe/` или добавили PNG в `overlays/` → `/wardrobe reload`.
