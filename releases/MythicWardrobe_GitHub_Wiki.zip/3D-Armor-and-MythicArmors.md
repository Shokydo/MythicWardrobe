# 3D-броня, MythicArmors и комбо-модели

MythicWardrobe глубоко интегрирован с **MythicArmors** и **Minecraft 1.21.4+ Item Model Definitions** (`minecraft:composite`, `minecraft:select`).

---

## Архитектура 3D-рендеринга

В MythicWardrobe доступны **3 взаимодополняющих способа** одновременного ношения нескольких 3D-моделей (шлем + противогаз + 3D-причёска, бронежилет + рюкзак, поножи + 3D-пояс):

1. **Безлимитные 3D-слои головы (`minecraft:composite`, 0 лага):** команда `/wardrobe buildheadpack` объединяет все модели головы MythicArmors в один клиентский composite-предмет (от 2 до 12 слоёв одновременно). 3D-волосы + 3D-маска + 3D-шлем рендерятся самим клиентом Minecraft на кости `head` с **нулевой задержкой**.
2. **Склеенные комбо-модели (`combo-overrides.yml` + `/wardrobe merge`, 0 лага):** для нагрудника + рюкзака и поножей + 3D-пояса (где важна 100% синхронизация с поворотом торса и ног без отставания) две `.bbmodel` склеиваются в одну комбо-модель, а `combo-overrides.yml` автоматически подменяет визуал при надевании пары.
3. **Автоматический 3D-оверлей (без настройки правил):** если для пары предметов НЕ задано правило в `combo-overrides.yml`, MythicWardrobe всё равно отобразит второй 3D-предмет одновременно через синхронизированный ArmorStand / ItemDisplay (`display-3d.update-interval-ticks: 1`).

---

## Требования к `.bbmodel` для MythicArmors

### Канонические кости (`model_format: "free"`, перед — ось `-Z`)

| Часть брони | Канонические кости Blockbench | Выходной ключ MythicArmors |
| :--- | :--- | :--- |
| Шлем / Голова (`HEAD`) | `head` | `mythicarmor:<id>_head_piece` |
| Нагрудник / Рюкзак (`CHEST`) | `body`, `right_arm`, `left_arm` | `mythicarmor:<id>_chest_piece` |
| Поножи / Пояс (`LEGS`) | `waist`, `right_leg`, `left_leg` | `mythicarmor:<id>_legs_piece` |
| Ботинки (`FEET`) | `right_foot`, `left_foot` | `mythicarmor:<id>_feet_piece` |

### Вспомогательные текстуры внутри `.bbmodel`

MythicArmors ожидает вспомогательные текстуры внутри `.bbmodel` **не применёнными ни к одному кубу**:
- `<id>_main.png` — основная 3D-текстура (применяется к кубам)
- `<id>_main_e.png` — свечение / emissive (не применяется к кубам)
- `<id>_t.png` / `<id>_t_e.png` — перекрашиваемый слой (для `LEATHER_*` предметов, например 3D-причёски и кушак)
- `<id>_layer_1.png` — 2D-фоллбэк слой для `HEAD` / `CHEST` / `FEET` (для чистого нагрудника `CHEST` текстуру `_layer_2.png` добавлять **не нужно**!)
- `<id>_layer_2.png` — 2D-фоллбэк слой только для `LEGS` (поножи/пояса)
- `<id>_helmet.png`, `<id>_chestplate.png`, `<id>_leggings.png`, `<id>_boots.png` — иконки 16×16 в инвентаре

> **Совет:** в [MythicWardrobe Studio](MythicWardrobe-Studio-and-Web-Editor) при загрузке `.bbmodel` с одной `texture.png` недостающие `_layer_1.png`, `_layer_2.png` и иконки генерируются автоматически!

### Важное правило MythicArmors для `HEAD` vs `CHEST` / `LEGS` / `FEET`

- **Для `HEAD` (шлемы, 3D-маски, 3D-причёски):** **НЕ указывайте `Equippable.Model`**! В MythicMobs используйте только `Options.ItemModel: mythicarmor:<id>_head_piece` (3D-модель головы в Minecraft работает через `display_context: head`).
- **Для `CHEST`, `LEGS`, `FEET`:** указывайте **оба** поля:
  ```yaml
  Equippable:
    Model: mythicarmor:light_military_vest_chest_piece
    Slot: CHEST
    EquipSound: 'item.armor.equip_iron'
  Options:
    ItemModel: mythicarmor:light_military_vest_chest_piece
    Unbreakable: true
    HideFlags: true
  ```

---

## Безлимитные 3D-слои головы (`/wardrobe buildheadpack`)

Для одновременного ношения **3D-причёски + 3D-маски + 3D-шлема** без отставания и без сущностей:

1. Убедитесь, что MythicArmors сгенерировал `plugins/MythicArmors/pack.zip` (`/ma reload`).
2. Выполните:
   ```text
   /wardrobe buildheadpack 6
   ```
   (аргумент — максимум одновременных слоёв на голове от `2` до `12`, по умолчанию `6`).
3. Плагин создаст:
   - `plugins/MythicWardrobe/merged_pack.zip` — готовый ресурспак с `minecraft:composite` для всех моделей головы.
   - `plugins/MythicWardrobe/head_composite_manifest.json` — индекс моделей, который MythicWardrobe подхватывает автоматически.
4. Подключите `merged_pack.zip` вместо стандартного пака MythicArmors.

---

## Склейка комбо-моделей (`/wardrobe merge` и `combo-overrides.yml`)

Чтобы **рюкзак плотно сидел на бронежилете**, а **3D-пояс — на поножах** с нулевой задержкой:

### Шаг 1. Склеить два `.bbmodel` прямо с сервера
```text
/wardrobe merge tactical_warden tactical_backpack tactical_warden_backpack
/ma reload
```
Плагин объединит кубы, кости и сошьёт текстуры в один атлас, сохранив `tactical_warden_backpack.bbmodel` прямо в `plugins/MythicArmors/models/`. (То же самое можно визуально сделать в [MythicWardrobe Studio](MythicWardrobe-Studio-and-Web-Editor).)

### Шаг 2. Прописать правило в `plugins/MythicWardrobe/combo-overrides.yml`
```yaml
combos:
  tactical_vest_with_backpack:
    equipment-slot: CHEST
    primary-mythic-item: "TacticalWardenVest"
    secondary-slot: "backpack_3d"
    secondary-mythic-item: "TacticalBackpackArmor"
    result-mythic-item: "TacticalWardenVestBackpack"
    hide-secondary-display: true

  tactical_legs_with_belt:
    equipment-slot: LEGS
    primary-mythic-item: "TacticalWardenLeggings"
    secondary-slot: "belt_3d"
    secondary-mythic-item: "TacticalUtilityBelt3D"
    result-mythic-item: "TacticalWardenLegsWithBelt"
    hide-secondary-display: true
```

Теперь:
- Если надет только `TacticalBackpackArmor` — он отображается сам по себе.
- Если надет только `TacticalWardenVest` — отображается бронежилет.
- Если надеты **оба** — MythicWardrobe автоматически подменяет визуал слота `CHEST` на `TacticalWardenVestBackpack` и скрывает отдельный дисплей (`hide-secondary-display: true`)!

---

## Видимость косметической брони самому игроку (`PacketEvents`)

В `config.yml`:
```yaml
cosmetic-armor:
  enabled: true
  show-to-self: true
```
- Другие игроки всегда видят косметическую и комбо-броню.
- При установленном **PacketEvents** сам владелец также видит свою косметику в виде от 3-го лица (F5) через подмену пакетов `SET_SLOT` / `WINDOW_ITEMS`.
- В режиме **Creative** подмена пакетов для самого игрока автоматически отключается (чтобы клиентский инвентарь креатива не перезаписал реальную броню косметической).
