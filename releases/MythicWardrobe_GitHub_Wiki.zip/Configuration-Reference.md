# Справочник конфигов, диагностика и FAQ

## Все файлы в папке `plugins/MythicWardrobe/`

```text
plugins/MythicWardrobe/
├── config.yml                  # Основные настройки плагина (MineSkin, скины, клики, блокировки, 3D, триггеры, веб)
├── layers.yml                  # Определение всех 2D-слоёв скина, папок, алиасов и clear-outer-regions
├── priority.yml                # Порядок наложения 2D-слоёв сверху вниз
├── slots.yml                   # 4 раздела и 19 слотов экипировки (SKIN_LAYER / ARMOR_REAL / ARMOR_COSMETIC / DISPLAY_3D / ARMOR_OVERLAY)
├── menus.yml                   # Внешний вид 3 режимов меню (COMPACT / TABBED / UNIFIED), кнопки, CustomModelData
├── items.yml                   # Привязка MythicMobs ID к слотам, текстурам, блокировкам и вариантам
├── combo-overrides.yml         # Правила 0-lag комбо-подмен (шлем+маска, жилет+рюкзак, поножи+пояс)
├── hair-3d.yml                 # Автопривязка 2D-волос -> 3D-причёски и поведение под шлемами
├── cosmetic-variants.yml       # Мультимодальная косметика (1 предмет -> разные 3D-модели под разную броню)
├── messages.yml                # Префикс, заголовки и все тексты чата (MiniMessage + HEX + &-коды)
├── wardrobe.db                 # SQLite-база: сохранённые слоты игроков, bodytype, режим меню и вечный SHA-256 кэш скинов
├── overlays/                   # 64×64 PNG-текстуры слоёв (разложены по подпапкам из layers.yml)
├── base_skins/                 # Резервные default_classic.png и default_slim.png для offline-серверов
├── merged_pack.zip             # Создаётся командой /wardrobe buildheadpack (безлимитные 3D-слои головы)
└── head_composite_manifest.json# Индекс моделей головы (создаётся вместе с merged_pack.zip)
```

---

## Быстрый справочник ключей `config.yml`

| Секция / Ключ | Значение по умолчанию | Назначение |
| :--- | :---: | :--- |
| `mineskin.api-key` | `"YOUR_MINESKIN_API_KEY"` | Ключ MineSkin API v2 (ускоряет подпись скинов в 3–5×) |
| `mineskin.base-url` | `"https://api.mineskin.org"` | URL MineSkin v2 или вашего локального `selfhosted_skin_signer.py` |
| `mineskin.max-concurrency` | `4` | Количество параллельных запросов в MineSkin v2 |
| `mineskin.rebuild-debounce-ticks` | `8` | Задержка склейки серии изменений в один запрос (`8 тиков = 0.4с`) |
| `skin.backend` | `"AUTO"` | `AUTO` / `SKINSRESTORER` / `PAPER` |
| `skin.clear-all-outer-layer` | `false` | `false` — очищать 2-й слой базового скина точечно по `clear-outer-regions` |
| `skin.reapply-on-base-skin-change` | `true` | Пересобирать одежду поверх нового скина после `/skin <ник>` |
| `skin.defer-apply-while-gui-open` | `true` | Не закрывать открытый инвентарь/GUI при обновлении скина |
| `inventory-trigger.enabled` | `true` | Открывать гардероб кликом по ванильным слотам брони |
| `inventory-trigger.click-mode` | `"EMPTY_OR_RIGHT"` | `EMPTY_OR_RIGHT` / `ALWAYS` / `RIGHT_CLICK_ONLY` |
| `inventory-trigger.smart-cursor-equip` | `true` | Надевать одежду с курсора сразу при клике на слот брони |
| `inventory-trigger.right-click-quick-equip` | `true` | Надевать 2D-одежду ПКМ из хотбара |
| `inventory-trigger.disable-hand-right-click-armor-equip` | `true` | Запретить надевать броню (ванильную и 3D MythicArmors) через ПКМ в руке (основной и левой) |
| `blocking.default-mode` | `"UNEQUIP"` | `UNEQUIP` / `PREVENT` / `HIDE` |
| `blocking.locked-slot-material` | `"BARRIER"` | Иконка заблокированного слота в меню |
| `blocking.inherit-clear-outer-regions` | `true` | Наследовать очистку 2-го слоя от заблокированных слоёв |
| `cosmetic-armor.enabled` | `true` | Включить косметическую броню и комбо-модели |
| `cosmetic-armor.show-to-self` | `true` | Показывать косметику самому игроку в F5 (через PacketEvents) |
| `display-3d.enabled` | `true` | Включить 3D-оверлеи (`DISPLAY_3D` / `ARMOR_OVERLAY`) |
| `display-3d.update-interval-ticks` | `1` | Частота обновления позиции 3D-аксессуаров в тиках |
| `death.keep-wardrobe-items-on-death` | `true` | Сохранять вещи в кастомных слотах гардероба при смерти |
| `mythicmobs.trigger-item-equip-skills-in-gui` | `true` | Запускать `~onEquip` / `~onUnequip` при экипировке в GUI |
| `mythicmobs.trigger-real-armor-equip-skills-without-crucible` | `true` | Запускать триггеры для реальной брони, если нет MythicCrucible |
| `web-editor.enabled` | `true` | Включить/выключить встроенный тестовый `/wardrobe web` |
| `debug` | `false` | Подробный вывод работы MineSkin, MythicMobs и слотов в консоль |

---

## Диагностика через `/wardrobe debug [игрок]`

Команда выводит в чат полную техническую сводку:
- **Skin Backend** — `SkinsRestorer` или `PaperNative`
- **PacketEvents** — `ON` (вид в F5 работает) или `OFF (Paper fallback)`
- **BodyType (Arms)** — `wide` / `slim` и источник (`override` или `auto`)
- **Menu Mode** — текущий режим меню игрока и серверный `default`
- **Base Skin** — URL и вариант базового скина
- **Active 2D Layers (Z-order)** — активные 2D-слои в порядке отрисовки
- **Blocked Slots/Layers** — слоты/слои, заблокированные цельными костюмами
- **Equipped Custom Slots** — список занятых доп. слотов гардероба
- **Active 3D Displays** — число активных 3D-сущностей на игроке
- **Last Skin Hash** — SHA-256 последнего применённого скина

---

## Частые вопросы и решение проблем (FAQ)

### `/mm i give @s LightMilitaryVest` или `WhiteVestPaint` говорит, что предмет не найден
1. Убедитесь, что распаковали обновлённый **`MythicWardrobe_MythicArmors_TestPack.zip`** (размер ~110 KB, содержит 21 `.bbmodel` и файл `plugins/MythicMobs/Items/MilitaryWhitePaint_Example.yml`) **в корень сервера**, а не внутрь `plugins/`.
2. Перезагрузите плагины строго по порядку: `/ma reload` → `/mm reload` → `/wardrobe reload`.

### Не видно 3D-модель брони или она отображается как обычная кожаная броня
1. Выполните `/ma reload` и проверьте консоль MythicArmors на ошибки в `.bbmodel`.
2. Обновите клиентский/серверный ресурспак из `plugins/MythicArmors/pack.zip` (или соберите `plugins/MythicWardrobe/merged_pack.zip` командой `/wardrobe buildheadpack`).
3. Для `HEAD`-моделей проверьте, что в MythicMobs **НЕ** задан `Equippable.Model` — только `Options.ItemModel: mythicarmor:<id>_head_piece`.
4. Для `CHEST`/`LEGS`/`FEET` проверьте, что указаны **оба** поля: `Equippable.Model` и `Options.ItemModel`.

### Я сам в F5 не вижу косметическую броню, а другие игроки видят
1. Установите **PacketEvents** (`2.11+`) и убедитесь, что в `config.yml` стоит `cosmetic-armor.show-to-self: true`.
2. Обновитесь до **v1.11.1+** — начиная с этой версии F5-отображение и 3D-промоушен работают одинаково и в **Survival**, и в **Creative** (с защитой слотов `CreativeArmorGuard` от удаления и перезаписи настоящей брони).

### Скины меняются медленно (~6 секунд на новый образ)
1. Пропишите бесплатный API-ключ в `config.yml` → `mineskin.api-key` ([account.mineskin.org/keys](https://account.mineskin.org/keys)).
2. Запустите `/wardrobe prewarm` для прогрева кэша базовых скинов.
3. Повторные комбинации всегда применяются мгновенно из SQLite-кэша. Для очень высокого онлайна используйте [Self-Hosted Skin Signer](MineSkin-and-Performance).

### 3D-рюкзак слегка отстаёт при быстром повороте
Склейте конкретный бронежилет и рюкзак в единую комбо-модель командой:
```text
/wardrobe merge tactical_warden tactical_backpack tactical_warden_backpack
```
и добавьте правило в `combo-overrides.yml` — модель будет крепиться прямо на кость `body` клиента с **0 лага**!
