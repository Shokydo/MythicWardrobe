# MythicWardrobe Studio v2.2 (100% HTML + JS — без Python и без сервера!)

Полностью автономный чёрно-белый веб-редактор для **MythicWardrobe v1.9.0+** и **MythicArmors**.
Работает локально прямо в браузере (**Chrome, Edge, Firefox, Opera, Яндекс.Браузер, Safari**) —
**никакой Python, Node.js, сервер или интернет НЕ нужны!**

## Как открыть (1 шаг)
Просто **дважды кликните** по файлу **`MythicWardrobeStudio.html`** — студия сразу откроется в вашем браузере!
*(Или откройте `modular/index.html`, если хотите редактировать JS/CSS отдельно.)*

## Что нового в v2.2 (поддержка MythicWardrobe v1.9.0)
1. **💇 3D-Волосы: автопривязка к 2D-волосам и скрытие под шлемом (`hair-3d.yml`):**
   - Привяжите любую 3D-причёску к 2D-текстуре волос (напр. `hair_blonde.png` → `HairPonytail3D_Chestnut`).
   - Настройте поведение при надевании шлема:
     - `HIDE_ALL` — полное отключение по списку шлемов (`ALL` / `WHITELIST` / `BLACKLIST` + `exceptions`),
     - `PARTIAL_MODEL` — **частичное отключение выбранных кубов модели**: отмечайте галочками, какие части скрыть под шлемом (напр. высокий хвост и резинку), оставляя передние свисающие пряди!
   - Кнопка **«🪖 Тест: Надеть шлем»** прямо в 3D-окне мгновенно проверяет результат на манекене.
   - Автоматически экспортирует `<id>_under_helmet.bbmodel` + `<MythicId>HelmetSafe` + `plugins/MythicWardrobe/hair-3d.yml`!
2. **🖼 Загрузка 2D и 3D текстур + редактирование `Lore` / `Display` / `CustomModelData`:**
   - На 3D-модели: загружайте свои PNG для основной текстуры, маски покраски (`_t.png`), маски свечения (`_e.png`) и иконки + авто-доделка `_layer_1.png`/`_layer_2.png`.
   - На 2D-слоях: загружайте PNG, задавайте `MythicMobs ID`, `Display`, `Material`, `CustomModelData` и многострочное описание `Lore` — всё попадает напрямую в MythicMobs YAML.
3. **🪟 Визуальный GUI Редактор инвентаря (`menus.yml`, новая 4-я вкладка!):**
   - Интерактивная сетка Minecraft 9×(1..6) для всех режимов (`TABBED`, `UNIFIED`, `COMPACT HUB`, `HEAD`, `CHEST`, `LEGS`, `FEET`).
   - Настройка названия меню, размера, заполнителя (`filler` + `CMD`/`ItemModel`), иконок **пустых слотов (`empty-slots` с `CustomModelData` и `ItemModel`)**, кнопок (`BACK`, `RUN_COMMAND`, `SWITCH_TAB`, `OPEN_SECTION`, `SWITCH_MODE`, `CLOSE`) и декоративных предметов.
   - Копирование, скачивание `menus.yml` и автоматическое включение в общий ZIP-архив!
